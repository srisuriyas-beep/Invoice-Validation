import { useState, useCallback } from "react";
import { useDropzone } from "react-dropzone";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { useToast } from "@/hooks/use-toast";
import { Upload as UploadIcon, FileText, X, CheckCircle } from "lucide-react";
import { useNavigate } from "react-router-dom";

interface UploadedFile {
  file: File;
  progress: number;
  status: "uploading" | "success" | "error";
  id?: string;
}

const Upload = () => {
  const [uploadedFiles, setUploadedFiles] = useState<UploadedFile[]>([]);
  const [isUploading, setIsUploading] = useState(false);
  const { toast } = useToast();
  const navigate = useNavigate();

  const onDrop = useCallback((acceptedFiles: File[]) => {
    const newFiles = acceptedFiles.map(file => ({
      file,
      progress: 0,
      status: "uploading" as const,
    }));

    setUploadedFiles(prev => [...prev, ...newFiles]);
    uploadFiles(newFiles);
  }, []);

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop,
    accept: {
      'application/pdf': ['.pdf']
    },
    multiple: true,
  });

  const uploadFiles = async (files: UploadedFile[]) => {
    setIsUploading(true);

    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error("User not authenticated");

      for (let i = 0; i < files.length; i++) {
        const fileItem = files[i];
        
        try {
          // Update progress
          setUploadedFiles(prev =>
            prev.map(f => f.file === fileItem.file ? { ...f, progress: 25 } : f)
          );

          // Upload to Supabase Storage
          const fileName = `${user.id}/${Date.now()}-${fileItem.file.name}`;
          const { data: uploadData, error: uploadError } = await supabase.storage
            .from("invoices")
            .upload(fileName, fileItem.file);

          if (uploadError) throw uploadError;

          // Update progress
          setUploadedFiles(prev =>
            prev.map(f => f.file === fileItem.file ? { ...f, progress: 50 } : f)
          );

          // Create validation record
          const { data: validationData, error: validationError } = await supabase
            .from("invoice_validations")
            .insert({
              user_id: user.id,
              file_name: fileItem.file.name,
              file_path: uploadData.path,
              validation_status: "pending",
            })
            .select()
            .single();

          if (validationError) throw validationError;

          // Update progress
          setUploadedFiles(prev =>
            prev.map(f => f.file === fileItem.file ? { 
              ...f, 
              progress: 100, 
              status: "success",
              id: validationData.id 
            } : f)
          );

          toast({
            title: "Upload Successful",
            description: `${fileItem.file.name} uploaded successfully`,
          });

        } catch (error) {
          console.error("Upload error:", error);
          setUploadedFiles(prev =>
            prev.map(f => f.file === fileItem.file ? { ...f, status: "error" } : f)
          );
          
          toast({
            title: "Upload Failed",
            description: `Failed to upload ${fileItem.file.name}`,
            variant: "destructive",
          });
        }
      }
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to process uploads",
        variant: "destructive",
      });
    } finally {
      setIsUploading(false);
    }
  };

  const removeFile = (fileToRemove: UploadedFile) => {
    setUploadedFiles(prev => prev.filter(f => f.file !== fileToRemove.file));
  };

  const processValidation = (fileId: string) => {
    navigate(`/validations/${fileId}`);
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold">Upload PDF Invoices</h1>
        <p className="text-muted-foreground">
          Upload your PDF invoices for automated validation
        </p>
      </div>

      {/* Upload Area */}
      <Card className="shadow-elegant">
        <CardHeader>
          <CardTitle>Select Files</CardTitle>
          <CardDescription>
            Drag and drop PDF files here, or click to select files
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div
            {...getRootProps()}
            className={`
              border-2 border-dashed rounded-lg p-8 text-center cursor-pointer transition-colors
              ${isDragActive 
                ? "border-primary bg-primary/5" 
                : "border-muted-foreground/25 hover:border-primary/50"
              }
            `}
          >
            <input {...getInputProps()} />
            <UploadIcon className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
            {isDragActive ? (
              <p className="text-lg font-medium">Drop the files here...</p>
            ) : (
              <div>
                <p className="text-lg font-medium mb-2">
                  Drag & drop PDF files here, or click to select
                </p>
                <p className="text-sm text-muted-foreground">
                  Supports multiple PDF files
                </p>
              </div>
            )}
          </div>
        </CardContent>
      </Card>

      {/* Uploaded Files */}
      {uploadedFiles.length > 0 && (
        <Card className="shadow-elegant">
          <CardHeader>
            <CardTitle>Uploaded Files</CardTitle>
            <CardDescription>
              Track the progress of your file uploads
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {uploadedFiles.map((fileItem, index) => (
                <div key={index} className="flex items-center space-x-4 p-4 border rounded-lg">
                  <FileText className="h-8 w-8 text-primary" />
                  <div className="flex-1">
                    <p className="font-medium">{fileItem.file.name}</p>
                    <p className="text-sm text-muted-foreground">
                      {(fileItem.file.size / 1024 / 1024).toFixed(2)} MB
                    </p>
                    {fileItem.status === "uploading" && (
                      <Progress value={fileItem.progress} className="mt-2" />
                    )}
                  </div>
                  <div className="flex items-center space-x-2">
                    {fileItem.status === "success" && (
                      <>
                        <CheckCircle className="h-5 w-5 text-success" />
                        <Button 
                          size="sm" 
                          onClick={() => processValidation(fileItem.id!)}
                          className="bg-gradient-primary"
                        >
                          Process
                        </Button>
                      </>
                    )}
                    {fileItem.status === "error" && (
                      <X className="h-5 w-5 text-destructive" />
                    )}
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => removeFile(fileItem)}
                      disabled={fileItem.status === "uploading"}
                    >
                      <X className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
};

export default Upload;